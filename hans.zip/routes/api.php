<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\JasaController;
use App\Http\Controllers\Api\RoleController;
use App\Http\Controllers\Api\StaffController;
use App\Http\Controllers\Api\ProdukController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Api\KategoriController;
use App\Http\Controllers\Api\SupplierController;
use App\Http\Controllers\Api\TransaksiController;
use App\Http\Controllers\Api\PelangganfController;
use App\Http\Controllers\Api\PengadaanStokController;
use App\Http\Controllers\Api\DetailTransaksiController;
use App\Http\Controllers\Api\DetailTransaksiJasController;
use App\Http\Controllers\Api\DetailPengadaanStokController;
use App\Http\Controllers\Api\DetailTransaksiJasaController;
use App\Http\Controllers\Api\DetailTransaksiGabunganController;

Route::post('/login', [LoginController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [LoginController::class, 'logout']);

    Route::middleware('role:Super Admin')->group(function () {
        Route::apiResource('role', RoleController::class);
        Route::apiResource('staff', StaffController::class);
        Route::apiResource('supplier', SupplierController::class);
        Route::apiResource('pelanggan', PelangganfController::class);
        Route::apiResource('kategori', KategoriController::class);
        Route::apiResource('produk', ProdukController::class);
        Route::apiResource('jasa', JasaController::class);
        Route::apiResource('pengadaanstok', PengadaanStokController::class);
        Route::apiResource('detailpengadaanstok', DetailPengadaanStokController::class);
        Route::apiResource('transaksi', TransaksiController::class);
        Route::apiResource('detailtransaksi', DetailTransaksiController::class);
        Route::apiResource('detailtransaksijasa', DetailTransaksiJasaController::class);
        Route::get('detailtransaksigabungan/{transaksi}', [DetailTransaksiGabunganController::class, 'show']);
    });

});

  
        