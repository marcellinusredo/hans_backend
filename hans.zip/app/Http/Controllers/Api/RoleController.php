<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Support\Facades\Validator;

class RoleController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        return response()->json([
            'status' => true,
            'data' => Role::all()
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_role' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $role = Role::create([
            'nama_role' => $request->nama_role
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Role berhasil ditambahkan',
            'data' => $role
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $role = Role::find($id);
        if (!$role) {
            return response()->json(['status' => false, 'message' => 'Role tidak ditemukan'], 404);
        }

        return response()->json(['status' => true, 'data' => $role]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $role = Role::find($id);
        if (!$role) {
            return response()->json(['status' => false, 'message' => 'Role tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama_role' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $role->update([
            'nama_role' => $request->nama_role
        ]);

        return response()->json(['status' => true, 'message' => 'Role berhasil diupdate', 'data' => $role]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $role = Role::find($id);
        if (!$role) {
            return response()->json(['status' => false, 'message' => 'Role tidak ditemukan'], 404);
        }

        $role->delete();

        return response()->json(['status' => true, 'message' => 'Role berhasil dihapus']);
    }
}
