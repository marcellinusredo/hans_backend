<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Supplier;
use Illuminate\Support\Facades\Validator;

class SupplierController extends Controller
{
    ///GET /Menampilkan semua data
    public function index()
    {
         $suppliers = Supplier::select('nama_supplier', 'nomor_telp_supplier', 'alamat_supplier')->get();

            return response()->json([
                'status' => true,
                'data' => $suppliers
            ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_supplier' => 'required|string|max:255',
            'nomor_telp_supplier' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
            'alamat_supplier' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $supplier = Supplier::create([
            'nama_supplier' => $request->nama_supplier,
            'nomor_telp_supplier' => $request->nomor_telp_supplier,
            'alamat_supplier' => $request->alamat_supplier,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Supplier berhasil ditambahkan',
            'data' => $supplier
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
         // Ambil data supplier berdasarkan id
        $supplier = Supplier::select('nama_supplier', 'nomor_telp_supplier', 'alamat_supplier')
            ->where('id_supplier', $id)
            ->first();

    // Jika data tidak ditemukan
        if (!$supplier) {
            return response()->json([
                'status' => false,
                'message' => 'Data supplier tidak ditemukan'
            ], 404);
        }

    // Kirim data tanpa id_supplier
        return response()->json([
            'status' => true,
            'data' => $supplier
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $supplier = Supplier::find($id);
        if (!$supplier) {
            return response()->json(['status' => false, 'message' => 'Supplier tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama_supplier' => 'required|string|max:255',
            'nomor_telp_supplier' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
            'alamat_supplier' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $supplier->update([
            'nama_supplier' => $request->nama_supplier,
            'nomor_telp_supplier' => $request->nomor_telp_supplier,
            'alamat_supplier' => $request->alamat_supplier,
        ]);

        return response()->json(['status' => true, 'message' => 'Supplier berhasil diupdate', 'data' => $supplier]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $supplier = Supplier::find($id);
        if (!$supplier) {
            return response()->json(['status' => false, 'message' => 'Supplier tidak ditemukan'], 404);
        }

        $supplier->delete();

        return response()->json(['status' => true, 'message' => 'Supplier berhasil dihapus']);
    }
}
