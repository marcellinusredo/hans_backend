<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Produk;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class ProdukController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        $produks = Produk::with(['kategori:id_kategori,nama_kategori'])
        ->select('id_produk', 'kategori_id', 'nama_produk', 'harga_produk', 'stok_produk', 'deskripsi_produk', 'gambar_produk','kode_produk')
        ->get()
        ->map(function ($produk) {
            return [
                'nama_produk' => $produk->nama_produk,
                'kode_produk' => $produk->kode_produk,
                'kode_produk' => $produk->kode_produk,
                'nama_kategori' => $produk->kategori->nama_kategori,
                'harga_produk' => $produk->harga_produk,
                'stok_produk' => $produk->stok_produk,
                'deskripsi_produk' => $produk->deskripsi_produk,
                'gambar_produk' => $produk->gambar_produk,
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $produks
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kategori_id' => 'required|exists:kategori,id_kategori',
            'nama_produk' => 'required|string|max:255',
            'kode_produk' => 'required|string|max:255|unique:produk,kode_produk',
            'harga_produk' => 'required|numeric|min:0',
            'deskripsi_produk' => 'nullable|string',
            'gambar_produk' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Proses simpan gambar ke folder storage/app/public/produk jika ada
        $gambarPath = null;
        if ($request->hasFile('gambar_produk')) {
            $gambarPath = $request->file('gambar_produk')->store('produk', 'public');
        }
        
        $produk = Produk::create([
            'kategori_id' => $request->kategori_id,
            'nama_produk' => $request->nama_produk,
            'kode_produk' => $request->kode_produk,
            'kode_produk' => $request->kode_produk,
            'harga_produk' => $request->harga_produk,
            'stok_produk' => 0,
            'deskripsi_produk' => $request->deskripsi_produk,
            'gambar_produk' => $gambarPath,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Produk berhasil ditambahkan',
            'data' => $produk
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $produk = Produk::with(['kategori:id_kategori,nama_kategori'])
        ->select('id_produk', 'kategori_id', 'nama_produk', 'harga_produk', 'stok_produk', 'deskripsi_produk', 'gambar_produk','kode_produk')
        ->where('id_produk', $id)
        ->first();

        if (!$produk) {
            return response()->json([
                'status' => false,
                'message' => 'Data produk tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => [
                'nama_produk' => $produk->nama_produk,
                'kode_produk' => $produk->kode_produk,
                'nama_kategori' => $produk->kategori->nama_kategori,
                'harga_produk' => $produk->harga_produk,
                'stok_produk' => $produk->stok_produk,
                'deskripsi_produk' => $produk->deskripsi_produk,
                'gambar_produk' => $produk->gambar_produk,
            ]
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $produk = Produk::find($id);
        if (!$produk) {
            return response()->json(['status' => false, 'message' => 'Produk tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'kategori_id' => 'required|exists:kategori,id_kategori',
            'nama_produk' => 'required|string|max:255',
            'kode_produk' => 'required|string|max:255|unique:produk,kode_produk,' . $id . ',id_produk',
            'harga_produk' => 'required|numeric|min:0',
            'deskripsi_produk' => 'nullable|string',
            'gambar_produk' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

         // Proses update gambar
        if ($request->hasFile('gambar_produk')) {
            // Hapus gambar lama jika ada
            if ($produk->gambar_produk && Storage::disk('public')->exists($produk->gambar_produk)) {
                Storage::disk('public')->delete($produk->gambar_produk);
            }
            // Simpan gambar baru
            $produk->gambar_produk = $request->file('gambar_produk')->store('produk', 'public');
        }

        
        $produk->update([
            'kategori_id' => $request->kategori_id,
            'nama_produk' => $request->nama_produk,
            'kode_produk' => $request->kode_produk,
            'harga_produk' => $request->harga_produk,
            'deskripsi_produk' => $request->deskripsi_produk,
            'gambar_produk' => $produk->gambar_produk, // gambar bisa diubah atau tetap
        ]);

        return response()->json(['status' => true, 'message' => 'Produk berhasil diupdate', 'data' => $produk]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $produk = Produk::find($id);
        if (!$produk) {
            return response()->json(['status' => false, 'message' => 'Produk tidak ditemukan'], 404);
        }

        // Hapus file gambar jika ada
        if ($produk->gambar_produk && Storage::disk('public')->exists($produk->gambar_produk)) {
            Storage::disk('public')->delete($produk->gambar_produk);
        }

        $produk->delete();

        return response()->json(['status' => true, 'message' => 'Produk berhasil dihapus']);
    }
}
