<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DetailPengadaanStok;
use Illuminate\Http\Request;
use App\Models\PengadaanStok;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class PengadaanStokController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        $pengadaan = PengadaanStok::with(['supplier:id_supplier,nama_supplier'])
        ->select('id_pengadaan_stok', 'supplier_id', 'waktu_pengadaan_stok', 'total_harga_pengadaan_stok')
        ->get()
        ->map(function ($item) {
            return [
                'nama_supplier' => $item->supplier->nama_supplier,
                'waktu_pengadaan_stok' => $item->waktu_pengadaan_stok,
                'total_harga_pengadaan_stok' => $item->total_harga_pengadaan_stok,
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $pengadaan
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'supplier_id' => 'required|exists:supplier,id_supplier',
            'staff_id' => 'required|exists:staff,id_staff',
            'waktu_pengadaan_stok' => 'required|date_format:d/m/Y',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $waktu_pengadaan_stok = Carbon::createFromFormat('d/m/Y', $request->waktu_pengadaan_stok)->format('Y-m-d');

        $pengadaan_stok = PengadaanStok::create([
            'supplier_id' => $request->supplier_id,
            'staff_id' => $request->staff_id,
            'waktu_pengadaan_stok' => $waktu_pengadaan_stok,
            'total_harga_pengadaan_stok' => 0,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'PengadaanStok berhasil ditambahkan',
            'data' => $pengadaan_stok
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $pengadaan = PengadaanStok::with(['supplier:id_supplier,nama_supplier'])
        ->select('id_pengadaan_stok', 'supplier_id', 'waktu_pengadaan_stok', 'total_harga_pengadaan_stok')
        ->where('id_pengadaan_stok', $id)
        ->first();

        if (!$pengadaan) {
            return response()->json([
                'status' => false,
                'message' => 'Data pengadaan stok tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => [
                'nama_supplier' => $pengadaan->supplier->nama_supplier,
                'waktu_pengadaan_stok' => $pengadaan->waktu_pengadaan_stok,
                'total_harga_pengadaan_stok' => $pengadaan->total_harga_pengadaan_stok,
            ]
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $pengadaan_stok = PengadaanStok::find($id);
        if (!$pengadaan_stok) {
            return response()->json(['status' => false, 'message' => 'PengadaanStok tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'supplier_id' => 'required|exists:supplier,id_supplier',
            'staff_id' => 'required|exists:staff,id_staff',
            'waktu_pengadaan_stok' => 'required|date_format:d/m/Y',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $waktu_pengadaan_stok = Carbon::createFromFormat('d/m/Y', $request->waktu_pengadaan_stok)->format('Y-m-d');
        
        $pengadaan_stok->update([
            'supplier_id' => $request->supplier_id,
            'staff_id' => $request->staff_id,
            'waktu_pengadaan_stok' => $waktu_pengadaan_stok,
        ]);

        return response()->json(['status' => true, 'message' => 'PengadaanStok berhasil diupdate', 'data' => $pengadaan_stok]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $pengadaan_stok = PengadaanStok::find($id);
        if (!$pengadaan_stok) {
            return response()->json(['status' => false, 'message' => 'PengadaanStok tidak ditemukan'], 404);
        }

        $pengadaan_stok->delete();

        return response()->json(['status' => true, 'message' => 'PengadaanStok berhasil dihapus']);
    }

    
}
