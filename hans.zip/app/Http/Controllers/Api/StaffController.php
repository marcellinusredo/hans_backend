<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Staff;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class StaffController extends Controller
{
    ///GET /Menampilkan semua data
    public function index()
    {
        $staffs = Staff::with(['role:id_role,nama_role']) //pilih kolum di tabel role
        ->select('id_staff', 'role_id', 'nama_staff', 'nomor_telp_staff', 'alamat_staff', 'username_staff') //pilih kolum di tabel staff
        ->get() //smbil data koleksi
        ->map(function ($staff) { //memilih data yang ditampilkan
            return [
                'nama_staff' => $staff->nama_staff,
                'nomor_telp_staff' => $staff->nomor_telp_staff,
                'alamat_staff' => $staff->alamat_staff,
                'username_staff' => $staff->username_staff,
                'nama_role' => $staff->role->nama_role,
            ];
        });
        
        return response()->json([
            'status' => true,
            'data' => $staffs
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:role,id_role',
            'nama_staff' => 'required|string|max:255',
            'nomor_telp_staff' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
            'alamat_staff' => 'nullable|string',
            'username_staff' => 'required|string|unique:staff,username_staff',
            'password_staff' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $staff = Staff::create([
            'role_id' => $request->role_id,
            'nama_staff' => $request->nama_staff,
            'nomor_telp_staff' => $request->nomor_telp_staff,
            'alamat_staff' => $request->alamat_staff,
            'username_staff' => $request->username_staff,
            'password_staff' =>  Hash::make($request->password_staff),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Staff berhasil ditambahkan',
            'data' => $staff
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        // Ambil satu data staff berdasarkan ID, bersama data role-nya
        $staff = Staff::with(['role:id_role,nama_role']) // Ambil nama role
            ->select('id_staff', 'role_id', 'nama_staff', 'nomor_telp_staff', 'alamat_staff', 'username_staff') // Pilih kolom dari tabel staff
            ->where('id_staff', $id) // Cari berdasarkan id_staff
            ->first(); // Ambil satu data

        // Jika tidak ditemukan
        if (!$staff) {
            return response()->json([
                'status' => false,
                'message' => 'Data staff tidak ditemukan'
            ], 404);
        }

        // Format responsenya
        return response()->json([
            'status' => true,
            'data' => [
                'nama_staff' => $staff->nama_staff,
                'nomor_telp_staff' => $staff->nomor_telp_staff,
                'alamat_staff' => $staff->alamat_staff,
                'username_staff' => $staff->username_staff,
                'nama_role' => $staff->role->nama_role,
            ]
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $staff = Staff::find($id);
        if (!$staff) {
            return response()->json(['status' => false, 'message' => 'Staff tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:role,id_role',
            'nama_staff' => 'required|string|max:255',
            'nomor_telp_staff' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
            'alamat_staff' => 'nullable|string',
            'username_staff' => 'required|string|max:255|unique:staff,username_staff,' . $id . ',id_staff',
            'password_staff' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $staff->update([
            'role_id' => $request->role_id,
            'nama_staff' => $request->nama_staff,
            'nomor_telp_staff' => $request->nomor_telp_staff,
            'alamat_staff' => $request->alamat_staff,
            'username_staff' => $request->username_staff,
            'password_staff' => Hash::make($request->password_staff),
        ]);

        return response()->json(['status' => true, 'message' => 'Staff berhasil diupdate', 'data' => $staff]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $staff = Staff::find($id);
        if (!$staff) {
            return response()->json(['status' => false, 'message' => 'Staff tidak ditemukan'], 404);
        }

        $staff->delete();

        return response()->json(['status' => true, 'message' => 'Staff berhasil dihapus']);
    }
}
