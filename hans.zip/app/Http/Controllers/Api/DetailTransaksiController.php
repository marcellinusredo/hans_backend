<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DetailTransaksi;
use App\Models\Produk;
use App\Models\Transaksi;
use Illuminate\Support\Facades\Validator;

class DetailTransaksiController extends Controller
{
    //GET /Menampilkan semua data Detail Transaksi
    public function index()
    {
        return response()->json([
            'status' => true,
            'data' => DetailTransaksi::all()
        ]);
    }

    //POST /Menambah Data Detail Transaksi
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'produk_id' => 'required|exists:produk,id_produk',
            'transaksi_id' => 'required|exists:transaksi,id_transaksi',
            'jumlah_produk_detail_transaksi' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        //Menghitung subtotal
        $produk = Produk::findOrFail($request->produk_id);
        $harga = $produk->harga_produk;
        $jumlah = $request->jumlah_produk_detail_transaksi;
        $subtotal = $harga * $jumlah;

        $detail_transaksi = DetailTransaksi::create([
            'produk_id' => $request->produk_id,
            'transaksi_id' => $request->transaksi_id,
            'harga_produk_detail_transaksi' => $harga,
            'jumlah_produk_detail_transaksi' => $jumlah,
            'subtotal_produk_detail_transaksi' => $subtotal,
        ]);

        //Melakukan updat total harga
        Transaksi::updateTotalHarga($request->transaksi_id);

        return response()->json([
            'status' => true,
            'message' => 'DetailTransaksi berhasil ditambahkan',
            'data' => $detail_transaksi
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $detail_transaksi = DetailTransaksi::find($id);
        if (!$detail_transaksi) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksi tidak ditemukan'], 404);
        }

        return response()->json(['status' => true, 'data' => $detail_transaksi]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $detail_transaksi = DetailTransaksi::find($id);
        if (!$detail_transaksi) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksi tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'produk_id' => 'required|exists:produk,id_produk',
            'transaksi_id' => 'required|exists:transaksi,id_transaksi',
            'jumlah_produk_detail_transaksi' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $produk = Produk::findOrFail($request->produk_id);
        $harga = $produk->harga_produk;
        $jumlah = $request->jumlah_produk_detail_transaksi;
        $subtotal = $harga * $jumlah;

        $detail_transaksi->update([
            'produk_id' => $request->produk_id,
            'transaksi_id' => $request->transaksi_id,
            'harga_produk_detail_transaksi' => $harga,
            'jumlah_produk_detail_transaksi' => $jumlah,
            'subtotal_produk_detail_transaksi' => $subtotal,
        ]);

        //Melakukan updat total harga
        Transaksi::updateTotalHarga($request->transaksi_id);

        return response()->json(['status' => true, 'message' => 'DetailTransaksi berhasil diupdate', 'data' => $detail_transaksi]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $detail_transaksi = DetailTransaksi::find($id);
        if (!$detail_transaksi) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksi tidak ditemukan'], 404);
        }

        $transaksi_id = $detail_transaksi->transaksi_id;
        $detail_transaksi->delete();

        //Melakukan updat total harga
        Transaksi::updateTotalHarga($transaksi_id);

        return response()->json(['status' => true, 'message' => 'DetailTransaksi berhasil dihapus']);
    }
}
