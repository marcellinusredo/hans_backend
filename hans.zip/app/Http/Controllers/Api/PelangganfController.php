<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pelanggan;
use Illuminate\Support\Facades\Validator;

class PelangganfController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        $pelanggans = Pelanggan::select('nama_pelanggan', 'alamat_pelanggan', 'nomor_telp_pelanggan')->get();

        return response()->json([
            'status' => true,
            'data' => $pelanggans
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_pelanggan' => 'required|string|max:255',
            'alamat_pelanggan' => 'nullable|string',
            'nomor_telp_pelanggan' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $pelanggan = Pelanggan::create([
            'nama_pelanggan' => $request->nama_pelanggan,
            'alamat_pelanggan' => $request->alamat_pelanggan,
            'nomor_telp_pelanggan' => $request->nomor_telp_pelanggan,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Pelanggan berhasil ditambahkan',
            'data' => $pelanggan
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $pelanggan = Pelanggan::select('nama_pelanggan', 'alamat_pelanggan', 'nomor_telp_pelanggan')
        ->where('id_pelanggan', $id)
        ->first();

        if (!$pelanggan) {
            return response()->json([
                'status' => false,
                'message' => 'Data pelanggan tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $pelanggan
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $pelanggan = Pelanggan::find($id);
        if (!$pelanggan) {
            return response()->json(['status' => false, 'message' => 'Pelanggan tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama_pelanggan' => 'required|string|max:255',
            'alamat_pelanggan' => 'nullable|string',
            'nomor_telp_pelanggan' => ['nullable', 'regex:/^[0-9]+$/', 'min:10', 'max:15'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $pelanggan->update([
            'nama_pelanggan' => $request->nama_pelanggan,
            'alamat_pelanggan' => $request->alamat_pelanggan,
            'nomor_telp_pelanggan' => $request->nomor_telp_pelanggan,
        ]);

        return response()->json(['status' => true, 'message' => 'Pelanggan berhasil diupdate', 'data' => $pelanggan]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $pelanggan = Pelanggan::find($id);
        if (!$pelanggan) {
            return response()->json(['status' => false, 'message' => 'Pelanggan tidak ditemukan'], 404);
        }

        $pelanggan->delete();

        return response()->json(['status' => true, 'message' => 'Pelanggan berhasil dihapus']);
    }
}
