<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DetailTransaksiJasa;
use App\Models\Jasa;
use App\Models\Transaksi;
use Illuminate\Support\Facades\Validator;

class DetailTransaksiJasaController extends Controller
{
    //GET /Menampilkan semua data Detail transaksi Jasa
    public function index()
    {
        return response()->json([
            'status' => true,
            'data' => DetailTransaksiJasa::all()
        ]);
    }

    //POST /Menambah Data Detail Transaksi Jasa
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'transaksi_id' => 'required|exists:transaksi,id_transaksi',
            'jasa_id' => 'required|exists:jasa,id_jasa',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $jasa = Jasa::findOrFail($request->jasa_id);
        $harga = $jasa->harga_jasa;

        $detail_transaksi_jasa = DetailTransaksiJasa::create([
            'transaksi_id'=>$request->transaksi_id,
            'jasa_id'=>$request->jasa_id,
            'harga_jasa_detail_transaksi_jasa'=>$harga
        ]);

        // Melakukan Update Total Harga
        Transaksi::updateTotalHarga($request->transaksi_id);

        return response()->json([
            'status' => true,
            'message' => 'DetailTransaksiJasa berhasil ditambahkan',
            'data' => $detail_transaksi_jasa
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $detail_transaksi_jasa = DetailTransaksiJasa::find($id);
        if (!$detail_transaksi_jasa) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksiJasa tidak ditemukan'], 404);
        }

        return response()->json(['status' => true, 'data' => $detail_transaksi_jasa]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $detail_transaksi_jasa = DetailTransaksiJasa::find($id);
        if (!$detail_transaksi_jasa) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksiJasa tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'transaksi_id' => 'required|exists:transaksi,id_transaksi',
            'jasa_id' => 'required|exists:jasa,id_jasa',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $jasa = Jasa::findOrFail($request->jasak_id);
        $harga = $jasa->harga_jasa;

        $detail_transaksi_jasa->update([
            'transaksi_id'=>$request->transaksi_id,
            'jasa_id'=>$request->jasa_id,
            'harga_jasa_detail_transaksi_jasa'=>$harga
        ]);

        // Melakukan Update Total Harga
        Transaksi::updateTotalHarga($request->transaksi_id);

        return response()->json(['status' => true, 'message' => 'DetailTransaksiJasa berhasil diupdate', 'data' => $detail_transaksi_jasa]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $detail_transaksi_jasa = DetailTransaksiJasa::find($id);
        if (!$detail_transaksi_jasa) {
            return response()->json(['status' => false, 'message' => 'DetailTransaksiJasa tidak ditemukan'], 404);
        }

        $transaksi_id = $detail_transaksi_jasa->transaksi_id;
        $detail_transaksi_jasa->delete();

        // Melakukan Update Total Harga
        Transaksi::updateTotalHarga($transaksi_id);

        return response()->json(['status' => true, 'message' => 'DetailTransaksiJasa berhasil dihapus']);
    }
}
