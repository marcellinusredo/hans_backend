<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Jasa;
use Illuminate\Support\Facades\Validator;

class JasaController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        $jasas = Jasa::select('nama_jasa', 'harga_jasa', 'deskripsi_jasa')->get();

        return response()->json([
            'status' => true,
            'data' => $jasas
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_jasa' => 'required|string|max:255',
            'harga_jasa' => 'required|numeric|min:0',
            'deskripsi_jasa' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $jasa = Jasa::create([
            'nama_jasa' => $request->nama_jasa,
            'harga_jasa' => $request->harga_jasa,
            'deskripsi_jasa' => $request->deskripsi_jasa,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Jasa berhasil ditambahkan',
            'data' => $jasa
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $jasa = Jasa::select('nama_jasa', 'harga_jasa', 'deskripsi_jasa')
        ->where('id_jasa', $id)
        ->first();

        if (!$jasa) {
            return response()->json([
                'status' => false,
                'message' => 'Data jasa tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $jasa
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $jasa = Jasa::find($id);
        if (!$jasa) {
            return response()->json(['status' => false, 'message' => 'Jasa tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama_jasa' => 'required|string|max:255',
            'harga_jasa' => 'required|numeric|min:0',
            'deskripsi_jasa' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $jasa->update([
            'nama_jasa' => $request->nama_jasa,
            'harga_jasa' => $request->harga_jasa,
            'deskripsi_jasa' => $request->deskripsi_jasa,
        ]);

        return response()->json(['status' => true, 'message' => 'Jasa berhasil diupdate', 'data' => $jasa]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $jasa = Jasa::find($id);
        if (!$jasa) {
            return response()->json(['status' => false, 'message' => 'Jasa tidak ditemukan'], 404);
        }

        $jasa->delete();

        return response()->json(['status' => true, 'message' => 'Jasa berhasil dihapus']);
    }
}
