<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Transaksi;
use App\Models\DetailTransaksi;
use App\Models\DetailTransaksiJasa;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;

class TransaksiController extends Controller
{
    ///GET /Menampilkan semua data
    public function index()
    {
        $transaksis = Transaksi::with(['pelanggan:id_pelanggan,nama_pelanggan'])
        ->select('id_transaksi', 'pelanggan_id', 'waktu_transaksi', 'total_harga_transaksi')
        ->get()
        ->map(function ($item) {
            return [
                'nama_pelanggan' => $item->pelanggan->nama_pelanggan,
                'waktu_transaksi' => $item->waktu_transaksi,
                'total_harga_transaksi' => $item->total_harga_transaksi,
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $transaksis
        ]);
    }

    //POST /Menambah Data Transaksi
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pelanggan_id' => 'required|exists:pelanggan,id_pelanggan',
            'staff_id' => 'required|exists:staff,id_staff',
            'waktu_transaksi' => 'required|date_format:d/m/Y',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $waktu_transaksi = Carbon::createFromFormat('d/m/Y', $request->waktu_transaksi)->format('Y-m-d');
        //Total harga dibuat 0 di awal
        $transaksi = Transaksi::create([
            'pelanggan_id' => $request->pelanggan_id,
            'staff_id' => $request->staff_id,
            'waktu_transaksi' => $waktu_transaksi,
            'total_harga_transaksi' => 0,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Transaksi berhasil ditambahkan',
            'data' => $transaksi
        ], 201);
    }

    //GET /Menampilkan data Transaksi tertentu
    public function show(string $id)
    {
        $transaksi = Transaksi::with(['pelanggan:id_pelanggan,nama_pelanggan'])
        ->select('id_transaksi', 'pelanggan_id', 'waktu_transaksi', 'total_harga_transaksi')
        ->where('id_transaksi', $id)
        ->first();

        if (!$transaksi) {
            return response()->json([
                'status' => false,
                'message' => 'Data transaksi tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => [
                'nama_pelanggan' => $transaksi->pelanggan->nama_pelanggan,
                'waktu_transaksi' => $transaksi->waktu_transaksi,
                'total_harga_transaksi' => $transaksi->total_harga_transaksi,
            ]
        ]);
    }

    //PUT / Update data Transaksi tertentu
    public function update(Request $request, string $id)
    {
        $transaksi = Transaksi::find($id);
        if (!$transaksi) {
            return response()->json(['status' => false, 'message' => 'Transaksi tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'pelanggan_id' => 'required|exists:pelanggan,id_pelanggan',
            'staff_id' => 'required|exists:staff,id_staff',
            'waktu_transaksi' => 'required|date_format:d/m/Y',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $waktu_transaksi = Carbon::createFromFormat('d/m/Y', $request->waktu_transaksi)->format('Y-m-d');
        $transaksi->update([
            'pelanggan_id' => $request->pelanggan_id,
            'staff_id' => $request->staff_id,
            'waktu_transaksi' => $waktu_transaksi,
        ]);
        

        return response()->json(['status' => true, 'message' => 'Transaksi berhasil diupdate', 'data' => $transaksi]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $transaksi = Transaksi::find($id);
        if (!$transaksi) {
            return response()->json(['status' => false, 'message' => 'Transaksi tidak ditemukan'], 404);
        }

        $transaksi->delete();

        return response()->json(['status' => true, 'message' => 'Transaksi berhasil dihapus']);
    }

    

}
