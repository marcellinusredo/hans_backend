<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DetailPengadaanStok;
use App\Models\PengadaanStok;
use App\Models\Produk;
use Illuminate\Support\Facades\Validator;

class DetailPengadaanStokController extends Controller
{
    //GET /Menampilkan semua data Detail Pengadaan Stok
    public function index()
    {
        $details = DetailPengadaanStok::with(['produk:id_produk,nama_produk'])
        ->select('id_detail_pengadaan_stok','produk_id','harga_produk_detail_pengadaan_stok','jumlah_produk_detail_pengadaan_stok','subtotal_produk_detail_pengadaan_stok')
        ->get()
        ->map(function ($item) {
            return [
                'nama_produk' => $item->produk->nama_produk,
                'harga_produk_detail_pengadaan_stok' => $item->harga_produk_detail_pengadaan_stok,
                'jumlah_produk_detail_pengadaan_stok' => $item->jumlah_produk_detail_pengadaan_stok,
                'subtotal_produk_detail_pengadaan_stok' => $item->subtotal_produk_detail_pengadaan_stok,
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $details
        ]);

    }

    //POST /Menambah Detail Pengadaan Stok
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'produk_id' => 'required|exists:produk,id_produk',
            'pengadaan_stok_id' => 'required|exists:pengadaan_stok,id_pengadaan_stok',
            'harga_produk_detail_pengadaan_stok' => 'required|numeric|min:0',
            'jumlah_produk_detail_pengadaan_stok' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Menghitung subtotal Detail Pengadaan Stok
        $harga = $request->harga_produk_detail_pengadaan_stok;
        $jumlah = $request->jumlah_produk_detail_pengadaan_stok;
        $subtotal = $harga * $jumlah;

        // Menambah stok produk
        $produk = Produk::findOrFail($request->produk_id);
        $produk->stok_produk += $jumlah;
        $produk->save();

        $detail_pengadaan_stok = DetailPengadaanStok::create([
            'produk_id' => $request->produk_id,
            'pengadaan_stok_id' => $request->pengadaan_stok_id,
            'harga_produk_detail_pengadaan_stok' => $harga,
            'jumlah_produk_detail_pengadaan_stok' => $jumlah,
            'subtotal_produk_detail_pengadaan_stok' => $subtotal,
        ]);

        //Melakukan updat total harga
        PengadaanStok::updateTotalHarga($request->pengadaan_stok_id);

        return response()->json([
            'status' => true,
            'message' => 'DetailPengadaanStok berhasil ditambahkan',
            'data' => $detail_pengadaan_stok
        ], 201);
    }

    //GET /Menampilkan data Detail Pengadaan Stok tertentu
    public function show(string $id)
    {
        $detail = DetailPengadaanStok::with(['produk:id_produk,nama_produk'])
        ->select(
            'id_detail_pengadaan_stok',
            'produk_id',
            'harga_produk_detail_pengadaan_stok',
            'jumlah_produk_detail_pengadaan_stok',
            'subtotal_produk_detail_pengadaan_stok'
        )
        ->where('id_detail_pengadaan_stok', $id)
        ->first();

        if (!$detail) {
            return response()->json([
                'status' => false,
                'message' => 'Data detail pengadaan tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => [
                'nama_produk' => $detail->produk->nama_produk,
                'harga_produk_detail_pengadaan_stok' => $detail->harga_produk_detail_pengadaan_stok,
                'jumlah_produk_detail_pengadaan_stok' => $detail->jumlah_produk_detail_pengadaan_stok,
                'subtotal_produk_detail_pengadaan_stok' => $detail->subtotal_produk_detail_pengadaan_stok,
            ]
        ]);
    }

    //PUT / Update data Detail Pengadaan Stok tertentu
    public function update(Request $request, string $id)
    {
        $detail_pengadaan_stok = DetailPengadaanStok::find($id);
        if (!$detail_pengadaan_stok) {
            return response()->json(['status' => false, 'message' => 'DetailPengadaanStok tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'produk_id' => 'required|exists:produk,id_produk',
            'pengadaan_stok_id' => 'required|exists:pengadaan_stok,id_pengadaan_stok',
            'harga_produk_detail_pengadaan_stok' => 'required|numeric|min:0',
            'jumlah_produk_detail_pengadaan_stok' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        //Menghitung selisih 
        $produk = Produk::findOrFail($detail_pengadaan_stok->produk_id);
        $jumlah_lama = $detail_pengadaan_stok->jumlah_produk_detail_pengadaan_stok;
        $jumlah_baru = $request->jumlah_produk_detail_pengadaan_stok;
        $selisih = $jumlah_baru - $jumlah_lama;
        $produk->stok_produk += $selisih;
        $produk->save();

        //Menghitung subtotal baru 
        $harga = $request->harga_produk_detail_pengadaan_stok;
        $subtotal = $harga * $jumlah_baru;

        $detail_pengadaan_stok->update([
            'produk_id' => $request->produk_id,
            'pengadaan_stok_id' => $request->pengadaan_stok_id,
            'harga_produk_detail_pengadaan_stok' => $harga,
            'jumlah_produk_detail_pengadaan_stok' => $jumlah_baru,
            'subtotal_produk_detail_pengadaan_stok' => $subtotal,
        ]);

        //Melakukan updat total harga
        PengadaanStok::updateTotalHarga($request->pengadaan_stok_id);

        return response()->json(['status' => true, 'message' => 'DetailPengadaanStok berhasil diupdate', 'data' => $detail_pengadaan_stok]);
    }

    //DELETE / Hapus data Detail Pengadaan Stok tertentu
    public function destroy(string $id)
    {
        $detail_pengadaan_stok = DetailPengadaanStok::find($id);
        if (!$detail_pengadaan_stok) {
            return response()->json(['status' => false, 'message' => 'DetailPengadaanStok tidak ditemukan'], 404);
        }

        // Kurangi stok produk
        $produk = Produk::findOrFail($detail_pengadaan_stok->produk_id);
        $produk->stok_produk -= $detail_pengadaan_stok->jumlah_produk_detail_pengadaan_stok;
        $produk->save();

        $pengadaan_stok_id = $detail_pengadaan_stok->transaksi_id;
        $detail_pengadaan_stok->delete();

        //Melakukan updat total harga
        PengadaanStok::updateTotalHarga($pengadaan_stok_id);

        return response()->json(['status' => true, 'message' => 'DetailPengadaanStok berhasil dihapus']);
    }
}
