<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Kategori;
use Illuminate\Support\Facades\Validator;

class KategoriController extends Controller
{
    //GET /Menampilkan semua data
    public function index()
    {
        $kategoris = Kategori::select('nama_kategori', 'deskripsi_kategori')->get();

        return response()->json([
            'status' => true,
            'data' => $kategoris
        ]);
    }

    //POST /Menambah Data
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_kategori' => 'required|string|max:255',
            'deskripsi_kategori' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $kategori = Kategori::create([
            'nama_kategori' => $request->nama_kategori,
            'deskripsi_kategori' => $request->deskripsi_kategori,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Kategori berhasil ditambahkan',
            'data' => $kategori
        ], 201);
    }

    //GET /Menampilkan data tertentu
    public function show(string $id)
    {
        $kategori = Kategori::select('nama_kategori', 'deskripsi_kategori')
        ->where('id_kategori', $id)
        ->first();

        if (!$kategori) {
            return response()->json([
                'status' => false,
                'message' => 'Data kategori tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $kategori
        ]);
    }

    //PUT / Update data tertentu
    public function update(Request $request, string $id)
    {
        $kategori = Kategori::find($id);
        if (!$kategori) {
            return response()->json(['status' => false, 'message' => 'Kategori tidak ditemukan'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama_kategori' => 'required|string|max:255',
            'deskripsi_kategori' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $kategori->update([
            'nama_kategori' => $request->nama_kategori,
            'deskripsi_kategori' => $request->deskripsi_kategori,
        ]);

        return response()->json(['status' => true, 'message' => 'Kategori berhasil diupdate', 'data' => $kategori]);
    }

    //DELETE / Hapus data tertentu
    public function destroy(string $id)
    {
        $kategori = Kategori::find($id);
        if (!$kategori) {
            return response()->json(['status' => false, 'message' => 'Kategori tidak ditemukan'], 404);
        }

        $kategori->delete();

        return response()->json(['status' => true, 'message' => 'Kategori berhasil dihapus']);
    }
}
