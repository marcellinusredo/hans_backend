<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DetailTransaksi;
use App\Models\DetailTransaksiJasa;
use Illuminate\Http\Request;

class DetailTransaksiGabunganController extends Controller
{
    public function show($transaksiId)
    {
        // Ambil detail produk
        $produkDetails = DetailTransaksi::with(['produk:id_produk,nama_produk,kode_produk'])
            ->where('transaksi_id', $transaksiId)
            ->get()
            ->map(function ($item) {
                return [
                    'nama' => $item->produk->nama_produk,
                    'jenis' => 'Produk',
                    'kode' => $item->produk->kode_produk,
                    'harga' => $item->harga_produk_detail_transaksi,
                    'jumlah' => $item->jumlah_produk_detail_transaksi,
                    'subtotal' => $item->subtotal_produk_detail_transaksi,
                ];
            });

        // Ambil detail jasa
        $jasaDetails = DetailTransaksiJasa::with(['jasa:id_jasa,nama_jasa'])
            ->where('transaksi_id', $transaksiId)
            ->get()
            ->map(function ($item) {
                return [
                    'nama' => $item->jasa->nama_jasa,
                    'jenis' => 'Jasa',
                    'kode' => '-',
                    'harga' => $item->harga_jasa_detail_transaksi_jasa,
                    'jumlah' => 1, // Jasa biasanya dihitung 1 kali
                    'subtotal' => $item->harga_jasa_detail_transaksi_jasa,
                ];
            });

        // Gabungkan koleksi produk dan jasa
        $gabungan = $produkDetails->merge($jasaDetails);

        return response()->json([
            'status' => true,
            'data' => $gabungan,
        ]);
    }
}