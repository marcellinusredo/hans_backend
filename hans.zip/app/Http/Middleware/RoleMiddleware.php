<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, ...$roles)
    {
        $user = $request->user();

        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // Cek jika role user ada di list roles yang diizinkan
        if (!in_array($user->role->nama_role, $roles)) {
            return response()->json(['message' => 'Forbidden: akses ditolak'], 403);
        }

        return $next($request);
    }
}
